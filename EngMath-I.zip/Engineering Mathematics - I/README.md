# Engineering Mathematics – I

Lecture notes and question banks for **CSE-1001, Engineering Mathematics – I**,
BTech 1st Year, **IIIT Bhopal**.

These are teaching materials written for students meeting each topic properly
for the first time. Every abstract idea is introduced in the same three-step
order — **a concrete situation**, then **a picture**, then **the formal
definition** — so that a definition arrives as a way of recording something
already understood, rather than as a rule descending from nowhere.

---

## Contents

### Notes

| Document | Pages | Covers |
|---|---:|---|
| [`notes/sequences.pdf`](notes/sequences.pdf) | 22 | Bounded and monotone sequences, the ε–N definition, algebra of limits, Sandwich Theorem, Monotone Convergence Theorem, subsequences and Bolzano–Weierstrass, Cauchy sequences, ratio and root tests, the growth hierarchy |
| [`notes/series.pdf`](notes/series.pdf) | 20 | Partial sums, geometric and telescoping series, the *n*-th term test, the harmonic series, comparison and limit comparison, the integral test and *p*-series, D'Alembert's ratio test, Cauchy's root test, Leibniz's test, absolute vs conditional convergence, power and Taylor series |

**Read `sequences` before `series`.** A series is defined through the sequence
of its partial sums, so the second note uses the first from its opening page.

### Question banks

Each bank ships with its answer key as a **separate document**, so the
questions can be handed out on their own.

| Document | Pages | Contents |
|---|---:|---|
| [`question-banks/sequences-question-bank.pdf`](question-banks/sequences-question-bank.pdf) | 11 | 46 MCQ · 10 true/false · 20 short · 12 long · 8 critical |
| [`question-banks/sequences-answer-key.pdf`](question-banks/sequences-answer-key.pdf) | 10 | Answer key plus full worked solutions |
| [`question-banks/series-question-bank.pdf`](question-banks/series-question-bank.pdf) | 12 | 46 MCQ · 10 true/false · 20 short · 13 long · 8 critical |
| [`question-banks/series-answer-key.pdf`](question-banks/series-answer-key.pdf) | 13 | Answer key plus full worked solutions |

Every bank opens with a **coverage table** mapping each topic to the exact
questions that test it, so a lecturer can assemble a paper on one section
without reading the whole document.

---

## How the material is organised

Four kinds of callout box run through the notes:

| Box | Purpose |
|---|---|
| **The idea** | The intuition in plain language. Read these first when revising. |
| **In the real world** | Connects the mathematics to engineering, computing, biology and finance. |
| **Common mistake** | The errors students actually make in examinations. |
| **Try it yourself** | Two-minute questions to attempt *before* reading on. |

Two worked examples are carried across several sections rather than used once
and dropped:

- a **repeated drug dosage** model, `a₁ = 100`, `aₙ₊₁ = ½aₙ + 100`, posed in the
  motivation and closed later as a full application of the Monotone
  Convergence Theorem;
- the **Babylonian square-root algorithm**, which is solved by the same
  theorem and then returns as the standard example of a Cauchy sequence of
  rationals whose limit is irrational — which is how completeness of ℝ is
  motivated.

The notes contain 13 figures drawn in TikZ/pgfplots: ε-bands, the four
long-run behaviours of a sequence, the integral-test rectangles, partial sums
of an alternating series closing in on their limit, the growth hierarchy on a
log scale, a test-selection decision chart, and concept maps for both topics.

---

## For students

1. Read the note for a topic before the corresponding lecture, and again after.
2. Stop at every **Try it yourself** box and attempt it on the spot.
3. Once a section is finished, attempt the matching group of questions in the
   question bank.
4. Check the answer key **only after** a serious attempt. Comparing your own
   working line by line with a solution is where the learning happens; reading
   a solution cold is not studying.

## For instructors

- Each note carries a short **To the Instructor** section with course outcomes
  and a suggested pace (roughly six to seven contact hours per topic).
- The question banks are graded: Parts A–C for routine assessment, Part D for
  examination-style long answers, Part E for questions that separate a good
  script from an excellent one.
- Part E deliberately includes questions built on **common textbook
  misstatements** — for instance, the geometric-series condition written as
  `|r| ≤ 1` instead of `|r| < 1`, and "bounded" defined as `aₙ < M` for all *n*,
  which captures only boundedness from above. Students are asked to find the
  error themselves.

---

## Building from source

Everything is plain LaTeX with no external dependencies beyond a standard
TeX Live installation.

```bash
# Notes
cd notes
pdflatex sequences.tex && pdflatex sequences.tex && pdflatex sequences.tex

# Question banks
cd ../question-banks
pdflatex sequences-question-bank.tex && pdflatex sequences-question-bank.tex
```

Run `pdflatex` **three times** for the notes (table of contents and
cross-references) and twice for the question banks.

**Packages required:** `amsmath`, `amssymb`, `amsthm`, `geometry`, `enumitem`,
`booktabs`, `array`, `multicol`, `xcolor`, `tcolorbox`, `tikz`, `pgfplots`,
`hyperref`. All ship with a full TeX Live. `lmodern` is used if present and
skipped if not.

**Note on the question banks:** all four `.tex` files `\input` the shared
[`question-banks/qbank-preamble.tex`](question-banks/qbank-preamble.tex),
which must stay in the same directory. Editing that one file restyles all four
documents at once.

---

## Repository layout

```
Engineering Mathematics - I/
├── README.md
├── notes/
│   ├── sequences.tex        sequences.pdf
│   └── series.tex           series.pdf
└── question-banks/
    ├── qbank-preamble.tex               (shared style — keep alongside)
    ├── sequences-question-bank.tex      sequences-question-bank.pdf
    ├── sequences-answer-key.tex         sequences-answer-key.pdf
    ├── series-question-bank.tex         series-question-bank.pdf
    └── series-answer-key.tex            series-answer-key.pdf
```

---

## Errata

Corrections are welcome. If you find a mathematical error, a typo, or a place
where an explanation does not land, please open an issue giving the document,
the page and the question or equation number.

## Author

**Kanchan Rajwar**
Department of Mathematics, IIIT Bhopal
kanchan.rajwar@iiitbhopal.ac.in

## License

Released for educational use. Attribution appreciated if you adapt these
materials for your own course.
